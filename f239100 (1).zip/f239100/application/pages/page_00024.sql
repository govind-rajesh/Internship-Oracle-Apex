prompt --application/pages/page_00024
begin
--   Manifest
--     PAGE: 00024
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>27534538223393061751
,p_default_application_id=>239100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXPRACTICE702'
);
wwv_flow_imp_page.create_page(
 p_id=>24
,p_name=>'Task Details'
,p_page_mode=>'MODAL'
,p_step_title=>'Task Details'
,p_allow_duplicate_submissions=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.jQuery(() => {',
'    apex.jQuery("a.taskActionMenu").each((index, item) => {',
'        const element = apex.jQuery(item);',
'        const actionName = decodeURI(element.attr("href")).match(/\$([^?]+)/)[1];',
'        const actionLabel = element.text();',
'        apex.actions.add({',
'            name: actionName,',
'            label: actionLabel,',
'            action: (event, element, args) => {',
'                if (args.do === "submit") {',
'                    apex.page.submit(actionName.toUpperCase());',
'                }',
'                else if (args.do === "openRegion") {',
'                    apex.theme.openRegion(actionName.toUpperCase());',
'                }',
'            }',
'        });',
'    });',
'});'))
,p_step_template=>1661186590416509825
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_protection_level=>'C'
,p_page_component_map=>'27'
,p_created_on=>wwv_flow_imp.dz('20250619084646Z')
,p_last_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_last_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(56985306811897503452)
,p_plug_name=>'Subject'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select task_id,',
'       task_type,',
'       task_def_name,',
'       details_app_name,',
'       details_link_target,',
'       subject,',
'       initiator,',
'       actual_owner,',
'       priority,',
'       due_on,',
'       due_in,',
'       due_in_hours,',
'       due_code,',
'       state_code,',
'       is_completed,',
'       outcome,',
'       created_on,',
'       created_ago,',
'       created_ago_hours,',
'       last_updated_on,',
'       badge_text,',
'       badge_state',
'  from table ( apex_human_task.get_tasks (',
'                   p_context => ''SINGLE_TASK'',',
'                   p_task_id => :P24_TASK_ID ) );'))
,p_template_component_type=>'PARTIAL'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_landmark_type=>'region'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'BADGE_COL_WIDTH', 't-ContentRow-badge--auto',
  'BADGE_LABEL', 'State',
  'BADGE_LABEL_DISPLAY', 'N',
  'BADGE_SIZE', 't-Badge--md',
  'BADGE_STATE', 'BADGE_STATE',
  'BADGE_VALUE', 'BADGE_TEXT',
  'DESCRIPTION', wwv_flow_string.join(wwv_flow_t_varchar2(
    '<strong>&TASK_DEF_NAME!HTML.</strong>',
    '{if INITIATOR/}',
    '    <span role="separator" aria-label="&middot;"> &middot; </span>',
    '    &{APEX.TASK.INITIATED_BY_USER_SINCE 0=&INITIATOR!HTML. 1=&CREATED_AGO.}.',
    '{endif/}',
    '{if ACTUAL_OWNER/}',
    '    <span role="separator" aria-label="&middot;"> &middot; </span>',
    '    &{APEX.TASK.ASSIGNED_TO_USER 0=&ACTUAL_OWNER!HTML.}.',
    '{endif/}',
    '{if !IS_COMPLETED/}',
    '    {case DUE_CODE/}',
    '        {when OVERDUE/}',
    '            <span role="separator" aria-label="&middot;"> &middot; </span>',
    '            <strong class="u-danger-text">&{APEX.TASK.DUE_SINCE 0=&DUE_IN.}.</strong>',
    '        {when NEXT_HOUR/}',
    '            <span role="separator" aria-label="&middot;"> &middot; </span>',
    '            <strong class="u-danger-text">&{APEX.TASK.DUE_SINCE 0=&DUE_IN.}.</strong>',
    '        {when NEXT_24_HOURS/}',
    '            <span role="separator" aria-label="&middot;"> &middot; </span>',
    '            <span class="u-danger-text">&{APEX.TASK.DUE_SINCE 0=&DUE_IN.}.</span>',
    '        {otherwise/}',
    '            {if DUE_IN/}',
    '                <span role="separator" aria-label="&middot;"> &middot; </span>',
    '                &{APEX.TASK.DUE_SINCE 0=&DUE_IN.}.',
    '            {endif/}',
    '    {endcase/}',
    '{endif/}',
    '{if !IS_COMPLETED/}',
    '    <span role="separator" aria-label="&middot;"> &middot; </span>',
    '    {case PRIORITY/}',
    '        {when 1/}',
    '            <strong class="u-danger-text">&{APEX.TASK.PRIORITY.1.DESCRIPTION}.</strong>',
    '        {when 2/}',
    '            <span class="u-danger-text">&{APEX.TASK.PRIORITY.2.DESCRIPTION}.</span>',
    '        {when 3/}',
    '            &{APEX.TASK.PRIORITY.3.DESCRIPTION}.',
    '        {when 4/}',
    '            &{APEX.TASK.PRIORITY.4.DESCRIPTION}.',
    '        {when 5/}',
    '            &{APEX.TASK.PRIORITY.5.DESCRIPTION}.',
    '    {endcase/}',
    '{endif/}',
    '{if OUTCOME/}',
    '    <span role="separator" aria-label="&middot;"> &middot; </span>',
    '    &OUTCOME.',
    '{endif/}')),
  'DISPLAY_AVATAR', 'N',
  'DISPLAY_BADGE', 'Y',
  'TITLE', '&SUBJECT.')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250619084646Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56985307205336503453)
,p_name=>'TASK_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TASK_ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_is_primary_key=>true
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56985307699842503454)
,p_name=>'TASK_TYPE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TASK_TYPE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56985308123061503454)
,p_name=>'TASK_DEF_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TASK_DEF_NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56985308695904503454)
,p_name=>'DETAILS_APP_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DETAILS_APP_NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56985309146590503455)
,p_name=>'DETAILS_LINK_TARGET'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DETAILS_LINK_TARGET'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56985309624546503455)
,p_name=>'SUBJECT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SUBJECT'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56985310199183503456)
,p_name=>'INITIATOR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'INITIATOR'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>70
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56985310640010503456)
,p_name=>'ACTUAL_OWNER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ACTUAL_OWNER'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>80
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56985311185478503457)
,p_name=>'PRIORITY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PRIORITY'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>90
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56985311643381503457)
,p_name=>'DUE_ON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DUE_ON'
,p_data_type=>'TIMESTAMP_TZ'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>100
,p_format_mask=>'SINCE'
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56985312165994503457)
,p_name=>'DUE_IN'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DUE_IN'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>110
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56985312687275503458)
,p_name=>'DUE_IN_HOURS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DUE_IN_HOURS'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>120
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56985313153500503458)
,p_name=>'DUE_CODE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DUE_CODE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>130
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56985313687756503458)
,p_name=>'STATE_CODE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STATE_CODE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>140
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56985314172674503459)
,p_name=>'IS_COMPLETED'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'IS_COMPLETED'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>150
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56985314603008503459)
,p_name=>'OUTCOME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'OUTCOME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>160
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56985315130226503459)
,p_name=>'CREATED_ON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CREATED_ON'
,p_data_type=>'TIMESTAMP_TZ'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>170
,p_format_mask=>'SINCE'
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56985315612573503460)
,p_name=>'CREATED_AGO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CREATED_AGO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>180
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56985316194728503460)
,p_name=>'CREATED_AGO_HOURS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CREATED_AGO_HOURS'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>190
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56985316620355503460)
,p_name=>'LAST_UPDATED_ON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LAST_UPDATED_ON'
,p_data_type=>'TIMESTAMP_TZ'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>200
,p_format_mask=>'SINCE'
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56985317110456503461)
,p_name=>'BADGE_TEXT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_TEXT'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>210
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56985317645868503461)
,p_name=>'BADGE_STATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_STATE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>220
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(56985324044348503466)
,p_plug_name=>'Delegate'
,p_region_name=>'DELEGATE'
,p_parent_plug_id=>wwv_flow_imp.id(56985306811897503452)
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-nosize'
,p_plug_template=>1485369341786500999
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_human_task.is_allowed (',
'    p_task_id   => :P24_TASK_ID,',
'    p_operation => apex_human_task.c_task_op_delegate )'))
,p_plug_display_when_cond2=>'PLSQL'
,p_landmark_type=>'form'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(56985325633975503468)
,p_plug_name=>'Priority'
,p_region_name=>'SET_PRIORITY'
,p_parent_plug_id=>wwv_flow_imp.id(56985306811897503452)
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-nosize'
,p_plug_template=>1485369341786500999
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_human_task.is_allowed (',
'    p_task_id   => :P24_TASK_ID,',
'    p_operation => apex_human_task.c_task_op_set_priority )'))
,p_plug_display_when_cond2=>'PLSQL'
,p_landmark_type=>'form'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(56985327235215503469)
,p_plug_name=>'Due'
,p_region_name=>'SET_DUE_DATE'
,p_parent_plug_id=>wwv_flow_imp.id(56985306811897503452)
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-nosize'
,p_plug_template=>1485369341786500999
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_human_task.is_allowed (',
'    p_task_id   => :P24_TASK_ID,',
'    p_operation => apex_human_task.c_task_op_set_due_date )'))
,p_plug_display_when_cond2=>'PLSQL'
,p_landmark_type=>'form'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(56985328885757503471)
,p_plug_name=>'Request Information'
,p_region_name=>'REQUEST_INFO'
,p_parent_plug_id=>wwv_flow_imp.id(56985306811897503452)
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-nosize'
,p_plug_template=>1485369341786500999
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_human_task.is_allowed (',
'    p_task_id   => :P24_TASK_ID,',
'    p_operation => apex_human_task.c_task_op_request_info )'))
,p_plug_display_when_cond2=>'PLSQL'
,p_landmark_type=>'form'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(56985330443498503473)
,p_plug_name=>'Submit Information'
,p_region_name=>'SUBMIT_INFO'
,p_parent_plug_id=>wwv_flow_imp.id(56985306811897503452)
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-nosize'
,p_plug_template=>1485369341786500999
,p_plug_display_sequence=>50
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_human_task.is_allowed (',
'    p_task_id   => :P24_TASK_ID,',
'    p_operation => apex_human_task.c_task_op_submit_info )'))
,p_plug_display_when_cond2=>'PLSQL'
,p_landmark_type=>'form'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(56985332080503503474)
,p_plug_name=>'Invite Participant'
,p_region_name=>'ADD_OWNER'
,p_parent_plug_id=>wwv_flow_imp.id(56985306811897503452)
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-nosize'
,p_plug_template=>1485369341786500999
,p_plug_display_sequence=>60
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_human_task.is_allowed (',
'    p_task_id   => :P24_TASK_ID,',
'    p_operation => apex_human_task.c_task_op_add_owner )'))
,p_plug_display_when_cond2=>'PLSQL'
,p_landmark_type=>'form'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(56985333676167503475)
,p_plug_name=>'Remove Participant'
,p_region_name=>'REMOVE_OWNER'
,p_parent_plug_id=>wwv_flow_imp.id(56985306811897503452)
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-nosize'
,p_plug_template=>1485369341786500999
,p_plug_display_sequence=>70
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_human_task.is_allowed (',
'    p_task_id   => :P24_TASK_ID,',
'    p_operation => apex_human_task.c_task_op_remove_owner )'))
,p_plug_display_when_cond2=>'PLSQL'
,p_landmark_type=>'form'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(56985335270270503476)
,p_plug_name=>'Cancel Task'
,p_region_name=>'CANCEL'
,p_parent_plug_id=>wwv_flow_imp.id(56985306811897503452)
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-nosize'
,p_plug_template=>1485369341786500999
,p_plug_display_sequence=>80
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Do you really want to cancel this task?</p>',
'<p>This will mark the task as no longer needed.</p>'))
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_human_task.is_allowed (',
'    p_task_id   => :P24_TASK_ID,',
'    p_operation => apex_human_task.c_task_op_cancel )'))
,p_plug_display_when_cond2=>'PLSQL'
,p_landmark_type=>'form'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(56985336479911503477)
,p_plug_name=>'Details'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select param_static_id,',
'       param_label,',
'       param_value,',
'       is_updatable,',
'       is_required',
'  from apex_task_parameters',
' where task_id = :P24_TASK_ID',
'   and is_visible = ''Y''',
' order by param_label;'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_ajax_items_to_submit=>'P24_TASK_ID'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from apex_task_parameters',
' where task_id = :P24_TASK_ID'))
,p_landmark_type=>'region'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'N',
  'DISPLAY_AVATAR', 'N',
  'DISPLAY_BADGE', 'N',
  'HIDE_BORDERS', 'N',
  'OVERLINE', '&PARAM_LABEL.',
  'REMOVE_PADDING', 'N',
  'TITLE', '&PARAM_VALUE.')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56985336887126503477)
,p_name=>'PARAM_STATIC_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PARAM_STATIC_ID'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_is_primary_key=>true
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56985337367831503478)
,p_name=>'PARAM_LABEL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PARAM_LABEL'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_use_as_row_header=>true
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56985337801959503478)
,p_name=>'PARAM_VALUE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PARAM_VALUE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56985338362494503479)
,p_name=>'IS_UPDATABLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'IS_UPDATABLE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56985338864507503479)
,p_name=>'IS_REQUIRED'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'IS_REQUIRED'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(56985339898028503480)
,p_plug_name=>'Edit Parameter'
,p_parent_plug_id=>wwv_flow_imp.id(56985336479911503477)
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-nosize'
,p_plug_template=>1485369341786500999
,p_plug_display_sequence=>90
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P24_CAN_UPDATE_PARAMS = ''Y'''
,p_plug_display_when_cond2=>'PLSQL'
,p_landmark_type=>'form'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(56985343022301503482)
,p_plug_name=>'Comments'
,p_region_template_options=>'#DEFAULT#:js-useLocalStorage:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>60
,p_plug_item_display_point=>'BELOW'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apex_string.get_initials(created_by) as user_initials,',
'       ''u-color-''||ora_hash(created_by,45)  as user_css_class,',
'       created_by                           as user_name,',
'       text                                 as comment_text,',
'       created_on                           as comment_date',
'  from apex_task_comments',
' where nvl(:P24_ALL_COMMENTS, ''N'') = ''N''',
'       and task_id = :P24_TASK_ID',
'    or nvl(:P24_ALL_COMMENTS, ''N'') = ''Y''',
'       and task_id in ( ',
'                select task_id',
'                  from apex_tasks',
'               connect by prior previous_task_id = task_id',
'                 start with task_id = :P24_TASK_ID )',
' order by created_on desc'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$COMMENTS'
,p_ajax_items_to_submit=>'P24_TASK_ID,P24_ALL_COMMENTS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_plug_query_no_data_found=>'No Comments'
,p_no_data_found_icon_classes=>'fa-comments-o fa-lg'
,p_show_total_row_count=>false
,p_landmark_type=>'region'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'N',
  'AVATAR_CSS_CLASSES', '&USER_CSS_CLASS.',
  'AVATAR_DESCRIPTION', '&USER_NAME.',
  'AVATAR_INITIALS', 'USER_INITIALS',
  'AVATAR_SHAPE', 't-Avatar--circle',
  'AVATAR_TYPE', 'initials',
  'COMMENT_DATE', 'COMMENT_DATE',
  'COMMENT_TEXT', 'COMMENT_TEXT',
  'DISPLAY_AVATAR', 'Y',
  'STYLE', 't-Comments--chat',
  'USER_NAME', 'USER_NAME')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56985343450374503483)
,p_name=>'USER_INITIALS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'USER_INITIALS'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56985343920739503483)
,p_name=>'USER_CSS_CLASS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'USER_CSS_CLASS'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56985344457126503483)
,p_name=>'USER_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'USER_NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_use_as_row_header=>true
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56985344978723503484)
,p_name=>'COMMENT_TEXT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COMMENT_TEXT'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56985345432849503484)
,p_name=>'COMMENT_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COMMENT_DATE'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_format_mask=>'SINCE'
,p_use_as_row_header=>true
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(56985347147752503485)
,p_plug_name=>'Add Comment'
,p_parent_plug_id=>wwv_flow_imp.id(56985343022301503482)
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-nosize'
,p_plug_template=>1485369341786500999
,p_plug_display_sequence=>100
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_human_task.is_allowed (',
'    p_task_id   => :P24_TASK_ID,',
'    p_operation => apex_human_task.c_task_op_add_comment )'))
,p_plug_display_when_cond2=>'PLSQL'
,p_landmark_type=>'form'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(56985348736783503487)
,p_plug_name=>'History'
,p_region_template_options=>'#DEFAULT#:js-useLocalStorage:is-collapsed:t-Region--scrollBody'
,p_plug_template=>2664334895415463485
,p_plug_display_sequence=>70
,p_plug_item_display_point=>'BELOW'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select display_msg,',
'       event_creator,',
'       event_timestamp',
'  from table ( apex_human_task.get_task_history (',
'                   p_task_id     => :P24_TASK_ID,',
'                   p_include_all => :P24_ALL_HISTORY ) )',
' order by event_timestamp desc'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$COMMENTS'
,p_ajax_items_to_submit=>'P24_TASK_ID,P24_ALL_HISTORY'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_landmark_type=>'region'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'N',
  'COMMENT_DATE', 'EVENT_TIMESTAMP',
  'COMMENT_TEXT', 'DISPLAY_MSG',
  'DISPLAY_AVATAR', 'N',
  'STYLE', 't-Comments--basic',
  'USER_NAME', 'EVENT_CREATOR')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56985349135765503487)
,p_name=>'DISPLAY_MSG'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DISPLAY_MSG'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56985349641038503488)
,p_name=>'EVENT_CREATOR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EVENT_CREATOR'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_use_as_row_header=>true
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(56985350135397503488)
,p_name=>'EVENT_TIMESTAMP'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EVENT_TIMESTAMP'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_format_mask=>'SINCE'
,p_use_as_row_header=>true
,p_is_primary_key=>false
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(56985351020867503489)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--stickToBottom:t-ButtonRegion--slimPadding:margin-bottom-none'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(56985324884882503467)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(56985324044348503466)
,p_button_name=>'CLOSE_DELEGATE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Close'
,p_button_position=>'CLOSE'
,p_button_execute_validations=>'N'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(56985326456792503468)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(56985325633975503468)
,p_button_name=>'CLOSE_SET_PRIORITY'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Close'
,p_button_position=>'CLOSE'
,p_button_execute_validations=>'N'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(56985328068368503469)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(56985327235215503469)
,p_button_name=>'CLOSE_SET_DUE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Close'
,p_button_position=>'CLOSE'
,p_button_execute_validations=>'N'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(56985329628124503472)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(56985328885757503471)
,p_button_name=>'CLOSE_REQUEST_INFORMATION'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Close'
,p_button_position=>'CLOSE'
,p_button_execute_validations=>'N'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(56985331261665503473)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(56985330443498503473)
,p_button_name=>'CLOSE_SUBMIT_INFORMATION'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Close'
,p_button_position=>'CLOSE'
,p_button_execute_validations=>'N'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(56985332886579503474)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(56985332080503503474)
,p_button_name=>'CLOSE_INVITE_PARTICIPANT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Close'
,p_button_position=>'CLOSE'
,p_button_execute_validations=>'N'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(56985334422538503476)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(56985333676167503475)
,p_button_name=>'CLOSE_REMOVE_PARTICIPANT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Close'
,p_button_position=>'CLOSE'
,p_button_execute_validations=>'N'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(56985335688622503477)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(56985335270270503476)
,p_button_name=>'CLOSE_CANCEL_TASK'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Close'
,p_button_position=>'CLOSE'
,p_button_execute_validations=>'N'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(56985342216510503482)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(56985339898028503480)
,p_button_name=>'CLOSE_UPDATE_PARAMETER'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Close'
,p_button_position=>'CLOSE'
,p_button_execute_validations=>'N'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(56985347958777503486)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(56985347147752503485)
,p_button_name=>'CLOSE_ADD_COMMENT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Close'
,p_button_position=>'CLOSE'
,p_button_execute_validations=>'N'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(56985351429520503489)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(56985351020867503489)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(56985351826368503489)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(56985351020867503489)
,p_button_name=>'CLAIM'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Claim Task'
,p_button_position=>'CREATE'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_human_task.is_allowed (',
'    p_task_id   => :P24_TASK_ID,',
'    p_operation => apex_human_task.c_task_op_claim )'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(56985352228652503490)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(56985351020867503489)
,p_button_name=>'REJECT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--danger:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Reject'
,p_button_position=>'CREATE'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_human_task.is_allowed (',
'    p_task_id   => :P24_TASK_ID,',
'    p_operation => apex_human_task.c_task_op_reject )'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-times-circle-o'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(56985352687421503490)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(56985351020867503489)
,p_button_name=>'APPROVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--success:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Approve'
,p_button_position=>'CREATE'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_human_task.is_allowed (',
'    p_task_id   => :P24_TASK_ID,',
'    p_operation => apex_human_task.c_task_op_approve )'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-check'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(56985345995146503485)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(56985343022301503482)
,p_button_name=>'OPEN_DIALOG_ADD_COMMENT'
,p_button_static_id=>'OPEN_DIALOG_ADD_COMMENT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Add Comment'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'not apex_human_task.is_allowed (',
'    p_task_id   => :P24_TASK_ID,',
'    p_operation => apex_human_task.c_task_op_submit_info )',
'and apex_human_task.is_allowed (',
'    p_task_id   => :P24_TASK_ID,',
'    p_operation => apex_human_task.c_task_op_add_comment )'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(56985325272202503467)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(56985324044348503466)
,p_button_name=>'DELEGATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Delegate'
,p_button_position=>'EDIT'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(56985326809020503469)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(56985325633975503468)
,p_button_name=>'SET_PRIORITY'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Change Priority'
,p_button_position=>'EDIT'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(56985328460950503470)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(56985327235215503469)
,p_button_name=>'SET_DUE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Change Due Date'
,p_button_position=>'EDIT'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(56985330011207503472)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(56985328885757503471)
,p_button_name=>'REQUEST_INFORMATION'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Request Information'
,p_button_position=>'EDIT'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(56985331652680503474)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(56985330443498503473)
,p_button_name=>'SUBMIT_INFORMATION'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Submit Information'
,p_button_position=>'EDIT'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(56985333251348503475)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(56985332080503503474)
,p_button_name=>'INVITE_PARTICIPANT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Invite Participant'
,p_button_position=>'EDIT'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(56985334865498503476)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(56985333676167503475)
,p_button_name=>'REMOVE_PARTICIPANT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Remove Participant'
,p_button_position=>'EDIT'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(56985336034752503477)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(56985335270270503476)
,p_button_name=>'CANCEL_TASK'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Cancel Task'
,p_button_position=>'EDIT'
,p_button_css_classes=>'u-danger'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(56985342663012503482)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(56985339898028503480)
,p_button_name=>'UPDATE_PARAMETER'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'EDIT'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(56985346379695503485)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(56985343022301503482)
,p_button_name=>'OPEN_DIALOG_SUBMIT_INFORMATION'
,p_button_static_id=>'OPEN_DIALOG_SUBMIT_INFORMATION'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Submit Information'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_human_task.is_allowed (',
'    p_task_id   => :P24_TASK_ID,',
'    p_operation => apex_human_task.c_task_op_submit_info )'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(56985348388216503487)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(56985347147752503485)
,p_button_name=>'ADD_COMMENT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Comment'
,p_button_position=>'EDIT'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(56985381041962503507)
,p_branch_name=>'Reload Dialog'
,p_branch_action=>'f?p=&APP_ID.:&APP_PAGE_ID.:&APP_SESSION.::&DEBUG.::P24_TASK_ID:&P24_TASK_ID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56985305684737503450)
,p_name=>'P24_TASK_ID'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250619084646Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084646Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56985306030377503451)
,p_name=>'P24_CAN_UPDATE_PARAMS'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250619084646Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084646Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56985324488022503467)
,p_name=>'P24_NEW_OWNER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(56985324044348503466)
,p_prompt=>'New Owner'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select disp,',
'       val',
'  from table ( ',
'           apex_human_task.get_task_delegates ( ',
'               p_task_id => :P24_TASK_ID ) )'))
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'execute_validations', 'N',
  'page_action_on_selection', 'NONE')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56985326027690503468)
,p_name=>'P24_NEW_PRIORITY'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(56985325633975503468)
,p_prompt=>'New Priority'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select priority',
'  from apex_tasks',
' where task_id = :P24_TASK_ID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'UNIFIED_TASK_LIST.LOV.PRIORITY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select disp,',
'       val',
'  from table ( apex_human_task.get_lov_priority )',
' order by insert_order'))
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_protection_level=>'S'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56985327616028503469)
,p_name=>'P24_NEW_DUE_DATE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(56985327235215503469)
,p_use_cache_before_default=>'NO'
,p_prompt=>'New Due Date'
,p_format_mask=>'YYYY-MM-DD HH24:MI'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(due_on, ''YYYY-MM-DD HH24:MI'')',
'  from apex_tasks',
' where task_id = :P24_TASK_ID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'INLINE',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'Y',
  'use_defaults', 'Y')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56985329219063503472)
,p_name=>'P24_REQUEST_INFO_TEXT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(56985328885757503471)
,p_prompt=>'Message'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>7
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'Y',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56985330845739503473)
,p_name=>'P24_SUBMIT_INFO_TEXT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(56985330443498503473)
,p_prompt=>'Message'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>7
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'Y',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56985332437596503474)
,p_name=>'P24_NEW_POTENTIAL_OWNER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(56985332080503503474)
,p_prompt=>'New Potential Owner'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>100
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56985334016296503475)
,p_name=>'P24_POTENTIAL_OWNER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(56985333676167503475)
,p_prompt=>'Potential Owner'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select disp,',
'       val',
'  from table ( ',
'           apex_human_task.get_task_delegates ( ',
'               p_task_id => :P24_TASK_ID ) )'))
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'execute_validations', 'N',
  'page_action_on_selection', 'NONE')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56985340293433503480)
,p_name=>'P24_PARAM_STATIC_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(56985339898028503480)
,p_display_as=>'NATIVE_HIDDEN'
,p_warn_on_unsaved_changes=>'I'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56985340671262503480)
,p_name=>'P24_PARAM_LABEL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(56985339898028503480)
,p_prompt=>'Parameter'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56985341023603503481)
,p_name=>'P24_PARAM_VALUE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(56985339898028503480)
,p_prompt=>'Current Value'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56985341456367503481)
,p_name=>'P24_NEW_VALUE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(56985339898028503480)
,p_prompt=>'New Value'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>3
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56985341855342503481)
,p_name=>'P24_IS_REQUIRED'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(56985339898028503480)
,p_display_as=>'NATIVE_HIDDEN'
,p_warn_on_unsaved_changes=>'I'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56985346758861503485)
,p_name=>'P24_ALL_COMMENTS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(56985343022301503482)
,p_prompt=>'Include comments from expired tasks'
,p_source=>'N'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_grid_label_column_span=>0
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select task_id ',
'  from apex_tasks',
' where task_id = :P24_TASK_ID',
'   and previous_task_id is not null'))
,p_display_when_type=>'EXISTS'
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'checked_value', 'Y',
  'unchecked_value', 'N',
  'use_defaults', 'N')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56985347533164503486)
,p_name=>'P24_COMMENT_TEXT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(56985347147752503485)
,p_prompt=>'Comment'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>2000
,p_cHeight=>7
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'Y',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56985350698004503489)
,p_name=>'P24_ALL_HISTORY'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(56985348736783503487)
,p_prompt=>'Include history from expired tasks'
,p_source=>'N'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_grid_label_column_span=>0
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select task_id ',
'  from apex_tasks',
' where task_id = :P24_TASK_ID',
'   and previous_task_id is not null'))
,p_display_when_type=>'EXISTS'
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'checked_value', 'Y',
  'unchecked_value', 'N',
  'use_defaults', 'N')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(56985306454550503451)
,p_computation_sequence=>10
,p_computation_item=>'P24_CAN_UPDATE_PARAMS'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'case ',
'    when apex_human_task.is_allowed (',
'            p_task_id   => :P24_TASK_ID,',
'            p_operation => apex_human_task.c_task_op_set_params )',
'    then ''Y''',
'    else ''N''',
'end'))
,p_created_on=>wwv_flow_imp.dz('20250619084646Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084646Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(56985371834568503501)
,p_validation_name=>'Delegate'
,p_validation_sequence=>10
,p_validation=>'P24_NEW_OWNER'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Please provide a potential owner'
,p_when_button_pressed=>wwv_flow_imp.id(56985325272202503467)
,p_associated_item=>wwv_flow_imp.id(56985324488022503467)
,p_error_display_location=>'INLINE_WITH_FIELD'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(56985372237634503501)
,p_validation_name=>'Request Information'
,p_validation_sequence=>20
,p_validation=>'P24_REQUEST_INFO_TEXT'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Please provide a message'
,p_when_button_pressed=>wwv_flow_imp.id(56985330011207503472)
,p_associated_item=>wwv_flow_imp.id(56985329219063503472)
,p_error_display_location=>'INLINE_WITH_FIELD'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(56985372659692503502)
,p_validation_name=>'Submit Information'
,p_validation_sequence=>30
,p_validation=>'P24_SUBMIT_INFO_TEXT'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Please provide a message'
,p_when_button_pressed=>wwv_flow_imp.id(56985331652680503474)
,p_associated_item=>wwv_flow_imp.id(56985330845739503473)
,p_error_display_location=>'INLINE_WITH_FIELD'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(56985373007486503502)
,p_validation_name=>'Invite Participant'
,p_validation_sequence=>40
,p_validation=>'P24_NEW_POTENTIAL_OWNER'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Please provide a potential owner'
,p_when_button_pressed=>wwv_flow_imp.id(56985333251348503475)
,p_associated_item=>wwv_flow_imp.id(56985332437596503474)
,p_error_display_location=>'INLINE_WITH_FIELD'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(56985373421898503502)
,p_validation_name=>'Remove Participant'
,p_validation_sequence=>50
,p_validation=>'P24_POTENTIAL_OWNER'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Please provide a potential owner'
,p_when_button_pressed=>wwv_flow_imp.id(56985334865498503476)
,p_associated_item=>wwv_flow_imp.id(56985334016296503475)
,p_error_display_location=>'INLINE_WITH_FIELD'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(56985373852164503502)
,p_validation_name=>'Update Parameter'
,p_validation_sequence=>60
,p_validation=>'P24_NEW_VALUE'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Please provide a new parameter value'
,p_validation_condition=>':REQUEST = ''UPDATE_PARAMETER'' and :P24_IS_REQUIRED = ''Y'''
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_associated_item=>wwv_flow_imp.id(56985341456367503481)
,p_error_display_location=>'INLINE_WITH_FIELD'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(56985374256043503503)
,p_validation_name=>'Add Comment'
,p_validation_sequence=>70
,p_validation=>'P24_COMMENT_TEXT'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Please provide a comment'
,p_when_button_pressed=>wwv_flow_imp.id(56985348388216503487)
,p_associated_item=>wwv_flow_imp.id(56985347533164503486)
,p_error_display_location=>'INLINE_WITH_FIELD'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(56985353080873503490)
,p_name=>'Refresh - Comments'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P24_ALL_COMMENTS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(56985353448202503490)
,p_event_id=>wwv_flow_imp.id(56985353080873503490)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(56985343022301503482)
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(56985354877223503491)
,p_name=>'Edit Parameter'
,p_event_sequence=>10
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'a.parameter'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'body'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(56985355219033503491)
,p_event_id=>wwv_flow_imp.id(56985354877223503491)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(56985339898028503480)
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(56985355779748503492)
,p_event_id=>wwv_flow_imp.id(56985354877223503491)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(56985342663012503482)
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(56985356241029503492)
,p_event_id=>wwv_flow_imp.id(56985354877223503491)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P24_PARAM_STATIC_ID'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'apex.jQuery(this.triggeringElement).attr("data-id")'
,p_attribute_09=>'Y'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(56985356747780503492)
,p_event_id=>wwv_flow_imp.id(56985354877223503491)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P24_PARAM_LABEL'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'apex.jQuery(this.triggeringElement).attr("data-label")'
,p_attribute_09=>'Y'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(56985357217584503493)
,p_event_id=>wwv_flow_imp.id(56985354877223503491)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P24_PARAM_VALUE,P24_NEW_VALUE'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'apex.jQuery(this.triggeringElement).attr("data-value")'
,p_attribute_09=>'Y'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(56985357785835503493)
,p_event_id=>wwv_flow_imp.id(56985354877223503491)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P24_IS_REQUIRED'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'apex.jQuery(this.triggeringElement).attr("data-required")'
,p_attribute_09=>'Y'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(56985358230056503493)
,p_event_id=>wwv_flow_imp.id(56985354877223503491)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_FOCUS'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P24_NEW_VALUE'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(56985370463933503500)
,p_name=>'Disable/Enable Update Button'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P24_NEW_VALUE'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'apex.items.P24_NEW_VALUE.value != apex.items.P24_PARAM_VALUE.value'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keyup'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(56985370852864503500)
,p_event_id=>wwv_flow_imp.id(56985370463933503500)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(56985342663012503482)
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(56985371363104503501)
,p_event_id=>wwv_flow_imp.id(56985370463933503500)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(56985342663012503482)
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(56985353985881503491)
,p_name=>'Refresh - History'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P24_ALL_HISTORY'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(56985354363565503491)
,p_event_id=>wwv_flow_imp.id(56985353985881503491)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(56985348736783503487)
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(56985358799428503493)
,p_name=>'Add Comment'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(56985345995146503485)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(56985359104948503494)
,p_event_id=>wwv_flow_imp.id(56985358799428503493)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(56985347147752503485)
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(56985359616949503494)
,p_name=>'Submit Information'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(56985346379695503485)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(56985360087896503494)
,p_event_id=>wwv_flow_imp.id(56985359616949503494)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(56985330443498503473)
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(56985360590062503494)
,p_name=>'Cancel'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(56985351429520503489)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(56985360939701503495)
,p_event_id=>wwv_flow_imp.id(56985360590062503494)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(56985361469610503495)
,p_name=>'Close Delegate Dialog'
,p_event_sequence=>100
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(56985324884882503467)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(56985361868953503495)
,p_event_id=>wwv_flow_imp.id(56985361469610503495)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(56985324044348503466)
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(56985362306875503496)
,p_name=>'Close Change Priority Dialog'
,p_event_sequence=>110
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(56985326456792503468)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(56985362754962503496)
,p_event_id=>wwv_flow_imp.id(56985362306875503496)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(56985325633975503468)
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(56985363278837503496)
,p_name=>'Close Change Due Date Dialog'
,p_event_sequence=>120
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(56985328068368503469)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(56985363688136503496)
,p_event_id=>wwv_flow_imp.id(56985363278837503496)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(56985327235215503469)
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(56985364158978503496)
,p_name=>'Close Request Information Dialog'
,p_event_sequence=>130
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(56985329628124503472)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(56985364509687503497)
,p_event_id=>wwv_flow_imp.id(56985364158978503496)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(56985328885757503471)
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(56985365011692503497)
,p_name=>'Close Submit Information Dialog'
,p_event_sequence=>140
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(56985331261665503473)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(56985365402100503497)
,p_event_id=>wwv_flow_imp.id(56985365011692503497)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(56985330443498503473)
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(56985365941850503497)
,p_name=>'Close Invite Participant Dialog'
,p_event_sequence=>150
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(56985332886579503474)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(56985366333864503498)
,p_event_id=>wwv_flow_imp.id(56985365941850503497)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(56985332080503503474)
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(56985366808440503498)
,p_name=>'Close Remove Participant Dialog'
,p_event_sequence=>160
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(56985334422538503476)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(56985367226482503498)
,p_event_id=>wwv_flow_imp.id(56985366808440503498)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(56985333676167503475)
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(56985367793433503499)
,p_name=>'Close Cancel Task Dialog'
,p_event_sequence=>170
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(56985335688622503477)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(56985368185738503499)
,p_event_id=>wwv_flow_imp.id(56985367793433503499)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(56985335270270503476)
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(56985368600779503499)
,p_name=>'Close Edit Parameter Dialog'
,p_event_sequence=>180
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(56985342216510503482)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(56985369005487503499)
,p_event_id=>wwv_flow_imp.id(56985368600779503499)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(56985339898028503480)
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(56985369581415503500)
,p_name=>'Close Add Comment Dialog'
,p_event_sequence=>190
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(56985347958777503486)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(56985369941200503500)
,p_event_id=>wwv_flow_imp.id(56985369581415503500)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(56985347147752503485)
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(56985374683978503503)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_MANAGE_TASK'
,p_process_name=>'Renew Task'
,p_attribute_01=>'RENEW_TASK'
,p_attribute_02=>'P24_TASK_ID'
,p_attribute_09=>'P24_TASK_ID'
,p_process_error_message=>'#SQLERRM_TEXT#'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'RENEW'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_process_success_message=>'Task renewed'
,p_internal_uid=>56985374683978503503
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(56985375089289503503)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_MANAGE_TASK'
,p_process_name=>'Claim'
,p_attribute_01=>'CLAIM_TASK'
,p_attribute_02=>'P24_TASK_ID'
,p_process_error_message=>'#SQLERRM_TEXT#'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(56985351826368503489)
,p_internal_uid=>56985375089289503503
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(56985375477463503503)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_MANAGE_TASK'
,p_process_name=>'Approve'
,p_attribute_01=>'APPROVE_TASK'
,p_attribute_02=>'P24_TASK_ID'
,p_process_error_message=>'#SQLERRM_TEXT#'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(56985352687421503490)
,p_process_success_message=>'Task approved'
,p_internal_uid=>56985375477463503503
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(56985375809296503504)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_MANAGE_TASK'
,p_process_name=>'Reject'
,p_attribute_01=>'REJECT_TASK'
,p_attribute_02=>'P24_TASK_ID'
,p_process_error_message=>'#SQLERRM_TEXT#'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(56985352228652503490)
,p_process_success_message=>'Task rejected'
,p_internal_uid=>56985375809296503504
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(56985376254395503504)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_MANAGE_TASK'
,p_process_name=>'Release'
,p_attribute_01=>'RELEASE_TASK'
,p_attribute_02=>'P24_TASK_ID'
,p_process_error_message=>'#SQLERRM_TEXT#'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'RELEASE'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_process_success_message=>'Task released - can now be claimed by others'
,p_internal_uid=>56985376254395503504
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(56985376662882503504)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_MANAGE_TASK'
,p_process_name=>'Delegate'
,p_attribute_01=>'DELEGATE_TASK'
,p_attribute_02=>'P24_TASK_ID'
,p_attribute_04=>'P24_NEW_OWNER'
,p_process_error_message=>'#SQLERRM_TEXT#'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(56985325272202503467)
,p_process_success_message=>'Task delegated to &P24_NEW_OWNER!HTML.'
,p_internal_uid=>56985376662882503504
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(56985377042673503504)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_MANAGE_TASK'
,p_process_name=>'Change Priority'
,p_attribute_01=>'SET_TASK_PRIORITY'
,p_attribute_02=>'P24_TASK_ID'
,p_attribute_05=>'P24_NEW_PRIORITY'
,p_process_error_message=>'#SQLERRM_TEXT#'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(56985326809020503469)
,p_process_success_message=>'Task priority changed'
,p_internal_uid=>56985377042673503504
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(56985377403637503505)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_MANAGE_TASK'
,p_process_name=>'Change Due Date'
,p_attribute_01=>'SET_DUE_DATE'
,p_attribute_02=>'P24_TASK_ID'
,p_attribute_06=>'P24_NEW_DUE_DATE'
,p_process_error_message=>'#SQLERRM_TEXT#'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(56985328460950503470)
,p_process_success_message=>'Task due date updated'
,p_internal_uid=>56985377403637503505
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(56985377815265503505)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_MANAGE_TASK'
,p_process_name=>'Request Information'
,p_attribute_01=>'REQUEST_INFO'
,p_attribute_02=>'P24_TASK_ID'
,p_attribute_03=>'&P24_REQUEST_INFO_TEXT.'
,p_process_error_message=>'#SQLERRM_TEXT#'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(56985330011207503472)
,p_process_success_message=>'Information requested'
,p_internal_uid=>56985377815265503505
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(56985378292022503505)
,p_process_sequence=>100
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_MANAGE_TASK'
,p_process_name=>'Submit Information'
,p_attribute_01=>'SUBMIT_INFO'
,p_attribute_02=>'P24_TASK_ID'
,p_attribute_03=>'&P24_SUBMIT_INFO_TEXT.'
,p_process_error_message=>'#SQLERRM_TEXT#'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(56985331652680503474)
,p_process_success_message=>'Information submitted'
,p_internal_uid=>56985378292022503505
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(56985378681729503505)
,p_process_sequence=>110
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_MANAGE_TASK'
,p_process_name=>'Invite Participant'
,p_attribute_01=>'ADD_TASK_POTENTIAL_OWNER'
,p_attribute_02=>'P24_TASK_ID'
,p_attribute_04=>'P24_NEW_POTENTIAL_OWNER'
,p_process_error_message=>'#SQLERRM_TEXT#'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(56985333251348503475)
,p_process_success_message=>'Participant &P24_NEW_POTENTIAL_OWNER!HTML. added to task as potential owner'
,p_internal_uid=>56985378681729503505
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(56985379059463503505)
,p_process_sequence=>120
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_MANAGE_TASK'
,p_process_name=>'Remove Participant'
,p_attribute_01=>'REMOVE_POTENTIAL_OWNER'
,p_attribute_02=>'P24_TASK_ID'
,p_attribute_04=>'P24_POTENTIAL_OWNER'
,p_process_error_message=>'#SQLERRM_TEXT#'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(56985334865498503476)
,p_process_success_message=>'Participant &P24_POTENTIAL_OWNER!HTML. removed from task.'
,p_internal_uid=>56985379059463503505
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(56985379498299503506)
,p_process_sequence=>130
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_MANAGE_TASK'
,p_process_name=>'Cancel Task'
,p_attribute_01=>'CANCEL_TASK'
,p_attribute_02=>'P24_TASK_ID'
,p_process_error_message=>'#SQLERRM_TEXT#'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(56985336034752503477)
,p_process_success_message=>'Task canceled'
,p_internal_uid=>56985379498299503506
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(56985379879026503506)
,p_process_sequence=>140
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_MANAGE_TASK'
,p_process_name=>'Update Parameter'
,p_attribute_01=>'SET_TASK_PARAMS'
,p_attribute_02=>'P24_TASK_ID'
,p_attribute_10=>'P24_PARAM_STATIC_ID'
,p_attribute_11=>'P24_NEW_VALUE'
,p_process_error_message=>'#SQLERRM_TEXT#'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(56985342663012503482)
,p_process_success_message=>'Parameter updated'
,p_internal_uid=>56985379879026503506
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(56985380273490503506)
,p_process_sequence=>150
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_MANAGE_TASK'
,p_process_name=>'Add Comment'
,p_attribute_01=>'ADD_TASK_COMMENT'
,p_attribute_02=>'P24_TASK_ID'
,p_attribute_03=>'&P24_COMMENT_TEXT.'
,p_process_error_message=>'#SQLERRM_TEXT#'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(56985348388216503487)
,p_process_success_message=>'Comment added'
,p_internal_uid=>56985380273490503506
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(56985380668357503506)
,p_process_sequence=>160
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CLAIM,SET_PRIORITY,SET_DUE,INVITE_PARTICIPANT,REMOVE_PARTICIPANT,RENEW,UPDATE_PARAMETER,SAVE,ADD_COMMENT'
,p_process_when_type=>'REQUEST_NOT_IN_CONDITION'
,p_internal_uid=>56985380668357503506
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(56985318185383503462)
,p_region_id=>wwv_flow_imp.id(56985306811897503452)
,p_position_id=>362316004162771045
,p_display_sequence=>20
,p_template_id=>362317865359806322
,p_label=>'Actions'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-ellipsis-v'
,p_is_hot=>false
,p_show_as_disabled=>false
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(56985339325634503479)
,p_region_id=>wwv_flow_imp.id(56985336479911503477)
,p_position_id=>362316004162771045
,p_display_sequence=>10
,p_template_id=>362316605839802174
,p_label=>'Edit'
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
,p_link_attributes=>'class="parameter" data-id="&PARAM_STATIC_ID!ATTR." data-label="&PARAM_LABEL!ATTR." data-value="&PARAM_VALUE!ATTR." data-required="&IS_REQUIRED!ATTR." aria-haspopup="dialog"'
,p_button_display_type=>'TEXT'
,p_is_hot=>false
,p_show_as_disabled=>false
,p_condition_type=>'EXPRESSION'
,p_condition_expr1=>':IS_UPDATABLE = ''Y'' and :P24_CAN_UPDATE_PARAMS = ''Y'''
,p_condition_expr2=>'PLSQL'
,p_exec_cond_for_each_row=>true
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(56985318617849503462)
,p_component_action_id=>wwv_flow_imp.id(56985318185383503462)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Renew Task'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#action$renew?do=submit'
,p_link_attributes=>'class="taskActionMenu"'
,p_condition_type=>'EXPRESSION'
,p_condition_expr1=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_human_task.is_allowed (',
'    p_task_id   => :P24_TASK_ID,',
'    p_operation => apex_human_task.c_task_op_renew )'))
,p_condition_expr2=>'PLSQL'
,p_exec_cond_for_each_row=>true
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(56985319229350503463)
,p_component_action_id=>wwv_flow_imp.id(56985318185383503462)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Release'
,p_display_sequence=>20
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#action$release?do=submit'
,p_link_attributes=>'class="taskActionMenu"'
,p_condition_type=>'EXPRESSION'
,p_condition_expr1=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_human_task.is_allowed (',
'    p_task_id   => :P24_TASK_ID,',
'    p_operation => apex_human_task.c_task_op_release )'))
,p_condition_expr2=>'PLSQL'
,p_exec_cond_for_each_row=>true
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(56985319833782503463)
,p_component_action_id=>wwv_flow_imp.id(56985318185383503462)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Delegate'
,p_display_sequence=>30
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#action$delegate?do=openRegion'
,p_link_attributes=>'class="taskActionMenu"'
,p_condition_type=>'EXPRESSION'
,p_condition_expr1=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_human_task.is_allowed (',
'    p_task_id   => :P24_TASK_ID,',
'    p_operation => apex_human_task.c_task_op_delegate )'))
,p_condition_expr2=>'PLSQL'
,p_exec_cond_for_each_row=>true
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(56985320485743503463)
,p_component_action_id=>wwv_flow_imp.id(56985318185383503462)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Change Priority'
,p_display_sequence=>40
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#action$set_priority?do=openRegion'
,p_link_attributes=>'class="taskActionMenu"'
,p_condition_type=>'EXPRESSION'
,p_condition_expr1=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_human_task.is_allowed (',
'    p_task_id   => :P24_TASK_ID,',
'    p_operation => apex_human_task.c_task_op_set_priority )'))
,p_condition_expr2=>'PLSQL'
,p_exec_cond_for_each_row=>true
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(56985321008412503464)
,p_component_action_id=>wwv_flow_imp.id(56985318185383503462)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Change Due Date'
,p_display_sequence=>50
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#action$set_due_date?do=openRegion'
,p_link_attributes=>'class="taskActionMenu"'
,p_condition_type=>'EXPRESSION'
,p_condition_expr1=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_human_task.is_allowed (',
'    p_task_id   => :P24_TASK_ID,',
'    p_operation => apex_human_task.c_task_op_set_due_date )'))
,p_condition_expr2=>'PLSQL'
,p_exec_cond_for_each_row=>true
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(56985321603073503464)
,p_component_action_id=>wwv_flow_imp.id(56985318185383503462)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Request Information'
,p_display_sequence=>60
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#action$request_info?do=openRegion'
,p_link_attributes=>'class="taskActionMenu"'
,p_condition_type=>'EXPRESSION'
,p_condition_expr1=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_human_task.is_allowed (',
'    p_task_id   => :P24_TASK_ID,',
'    p_operation => apex_human_task.c_task_op_request_info )'))
,p_condition_expr2=>'PLSQL'
,p_exec_cond_for_each_row=>true
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(56985322218210503465)
,p_component_action_id=>wwv_flow_imp.id(56985318185383503462)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Invite Participant'
,p_display_sequence=>70
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#action$add_owner?do=openRegion'
,p_link_attributes=>'class="taskActionMenu"'
,p_condition_type=>'EXPRESSION'
,p_condition_expr1=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_human_task.is_allowed (',
'    p_task_id   => :P24_TASK_ID,',
'    p_operation => apex_human_task.c_task_op_add_owner )'))
,p_condition_expr2=>'PLSQL'
,p_exec_cond_for_each_row=>true
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(56985322856643503465)
,p_component_action_id=>wwv_flow_imp.id(56985318185383503462)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Remove Participant'
,p_display_sequence=>80
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#action$remove_owner?do=openRegion'
,p_link_attributes=>'class="taskActionMenu"'
,p_condition_type=>'EXPRESSION'
,p_condition_expr1=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_human_task.is_allowed (',
'    p_task_id   => :P24_TASK_ID,',
'    p_operation => apex_human_task.c_task_op_remove_owner )'))
,p_condition_expr2=>'PLSQL'
,p_exec_cond_for_each_row=>true
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(56985323421057503466)
,p_component_action_id=>wwv_flow_imp.id(56985318185383503462)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Cancel Task'
,p_display_sequence=>90
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#action$cancel?do=openRegion'
,p_link_attributes=>'class="taskActionMenu"'
,p_condition_type=>'EXPRESSION'
,p_condition_expr1=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_human_task.is_allowed (',
'    p_task_id   => :P24_TASK_ID,',
'    p_operation => apex_human_task.c_task_op_cancel )'))
,p_condition_expr2=>'PLSQL'
,p_exec_cond_for_each_row=>true
,p_created_on=>wwv_flow_imp.dz('20250619084647Z')
,p_updated_on=>wwv_flow_imp.dz('20250619084647Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp.component_end;
end;
/
