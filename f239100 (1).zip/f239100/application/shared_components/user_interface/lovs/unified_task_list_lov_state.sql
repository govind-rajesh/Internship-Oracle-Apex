prompt --application/shared_components/user_interface/lovs/unified_task_list_lov_state
begin
--   Manifest
--     UNIFIED_TASK_LIST.LOV.STATE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>27534538223393061751
,p_default_application_id=>239100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXPRACTICE702'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(56962111792545943435)
,p_lov_name=>'UNIFIED_TASK_LIST.LOV.STATE'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select disp,',
'       val',
'  from table ( apex_human_task.get_lov_state )',
' order by insert_order'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'VAL'
,p_display_column_name=>'DISP'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>15633419340604
,p_created_on=>wwv_flow_imp.dz('20250619070829Z')
,p_updated_on=>wwv_flow_imp.dz('20250619070829Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp.component_end;
end;
/
