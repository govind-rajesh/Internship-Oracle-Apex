prompt --application/shared_components/logic/build_options
begin
--   Manifest
--     BUILD OPTIONS: 239100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>27534538223393061751
,p_default_application_id=>239100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXPRACTICE702'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(54650442436467145814)
,p_build_option_name=>'Commented Out'
,p_build_option_status=>'EXCLUDE'
,p_version_scn=>15631431684508
,p_created_on=>wwv_flow_imp.dz('20250611144745Z')
,p_updated_on=>wwv_flow_imp.dz('20250611144745Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp.component_end;
end;
/
