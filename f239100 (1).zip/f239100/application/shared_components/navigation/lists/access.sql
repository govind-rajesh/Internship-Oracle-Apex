prompt --application/shared_components/navigation/lists/access
begin
--   Manifest
--     LIST: Access
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>27534538223393061751
,p_default_application_id=>239100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXPRACTICE702'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(56795196079055896616)
,p_name=>'Access'
,p_list_status=>'PUBLIC'
,p_version_scn=>15633297521449
,p_created_on=>wwv_flow_imp.dz('20250618181933Z')
,p_updated_on=>wwv_flow_imp.dz('20250618181933Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp.component_end;
end;
/
