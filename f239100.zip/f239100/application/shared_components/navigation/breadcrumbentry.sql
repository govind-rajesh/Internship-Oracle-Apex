prompt --application/shared_components/navigation/breadcrumbentry
begin
--   Manifest
--     BREADCRUMB ENTRY: 
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>27534538223393061751
,p_default_application_id=>239100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXPRACTICE702'
);
null;
wwv_flow_imp.component_end;
end;
/
