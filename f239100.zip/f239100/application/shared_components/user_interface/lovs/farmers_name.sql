prompt --application/shared_components/user_interface/lovs/farmers_name
begin
--   Manifest
--     FARMERS.NAME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>27534538223393061751
,p_default_application_id=>239100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXPRACTICE702'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(55496392553173615724)
,p_lov_name=>'FARMERS.NAME'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'FARMERS'
,p_return_column_name=>'ID'
,p_display_column_name=>'NAME'
,p_default_sort_column_name=>'NAME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>15632220926509
,p_created_on=>wwv_flow_imp.dz('20250614182017Z')
,p_updated_on=>wwv_flow_imp.dz('20250614182017Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp.component_end;
end;
/
