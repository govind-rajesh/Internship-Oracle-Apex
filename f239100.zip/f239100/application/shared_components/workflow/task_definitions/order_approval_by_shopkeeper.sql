prompt --application/shared_components/workflow/task_definitions/order_approval_by_shopkeeper
begin
--   Manifest
--     TASK_DEF: Order Approval By Shopkeeper
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>27534538223393061751
,p_default_application_id=>239100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXPRACTICE702'
);
wwv_flow_imp_shared.create_task_def(
 p_id=>wwv_flow_imp.id(56957818818136829932)
,p_name=>'Order Approval By Shopkeeper'
,p_static_id=>'ORDER_APPROVAL_BY_SHOPKEEPER'
,p_subject=>'Order Should be approved by the Shopkeeper'
,p_task_type=>'APPROVAL'
,p_priority=>3
,p_expiration_policy=>'NONE'
,p_max_renewal_count=>3
,p_initiator_can_complete=>false
,p_created_on=>wwv_flow_imp.dz('20250619000000Z')
,p_updated_on=>wwv_flow_imp.dz('20250619080658Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_shared.create_task_def_param(
 p_id=>wwv_flow_imp.id(56975742715768249386)
,p_task_def_id=>wwv_flow_imp.id(56957818818136829932)
,p_label=>'Customer Id'
,p_static_id=>'Customer_ID'
,p_data_type=>'VARCHAR2'
,p_is_required=>true
,p_is_visible=>true
,p_created_on=>wwv_flow_imp.dz('20250619080426Z')
,p_updated_on=>wwv_flow_imp.dz('20250619080426Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_shared.create_task_def_param(
 p_id=>wwv_flow_imp.id(56975743072834249387)
,p_task_def_id=>wwv_flow_imp.id(56957818818136829932)
,p_label=>'Id'
,p_static_id=>'ID'
,p_data_type=>'VARCHAR2'
,p_is_required=>true
,p_is_visible=>true
,p_created_on=>wwv_flow_imp.dz('20250619080426Z')
,p_updated_on=>wwv_flow_imp.dz('20250619080426Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp_shared.create_task_def_participant(
 p_id=>wwv_flow_imp.id(56976184253815294350)
,p_task_def_id=>wwv_flow_imp.id(56957818818136829932)
,p_participant_type=>'POTENTIAL_OWNER'
,p_identity_type=>'USER'
,p_value_type=>'STATIC'
,p_value=>'Shopkeeper'
,p_created_on=>wwv_flow_imp.dz('20250619080658Z')
,p_updated_on=>wwv_flow_imp.dz('20250619080658Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp.component_end;
end;
/
