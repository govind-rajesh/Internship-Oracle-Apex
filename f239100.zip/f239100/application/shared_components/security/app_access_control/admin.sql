prompt --application/shared_components/security/app_access_control/admin
begin
--   Manifest
--     ACL ROLE: Admin
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>27534538223393061751
,p_default_application_id=>239100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXPRACTICE702'
);
wwv_flow_imp_shared.create_acl_role(
 p_id=>wwv_flow_imp.id(54890778532347599541)
,p_static_id=>'ADMIN'
,p_name=>'Admin'
,p_version_scn=>15631659567236
);
wwv_flow_imp.component_end;
end;
/
