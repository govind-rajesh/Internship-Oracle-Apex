prompt --application/shared_components/security/app_access_control/agent
begin
--   Manifest
--     ACL ROLE: agent
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>27534538223393061751
,p_default_application_id=>239100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXPRACTICE702'
);
wwv_flow_imp_shared.create_acl_role(
 p_id=>wwv_flow_imp.id(54891120764259876233)
,p_static_id=>'AGENT'
,p_name=>'agent'
,p_version_scn=>15631659635193
);
wwv_flow_imp.component_end;
end;
/
