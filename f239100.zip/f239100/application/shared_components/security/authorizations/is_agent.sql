prompt --application/shared_components/security/authorizations/is_agent
begin
--   Manifest
--     SECURITY SCHEME: Is Agent
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>27534538223393061751
,p_default_application_id=>239100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXPRACTICE702'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(56607148908871296420)
,p_name=>'Is Agent'
,p_scheme_type=>'NATIVE_IS_IN_GROUP'
,p_attribute_01=>'agent'
,p_attribute_02=>'A'
,p_version_scn=>15633177534405
,p_caching=>'BY_USER_BY_PAGE_VIEW'
,p_created_on=>wwv_flow_imp.dz('20250618073344Z')
,p_updated_on=>wwv_flow_imp.dz('20250618074445Z')
,p_created_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
,p_updated_by=>'T.GOVIND.RAJESH@ACCENTURE.COM'
);
wwv_flow_imp.component_end;
end;
/
